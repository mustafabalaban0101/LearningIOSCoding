import UIKit

var ogrenciAdi = "Mustafa"
var ogrenciYas = 18
var ogrenciBoy = 1.77
var ogrenciBharf = "M"
var ogrenciDevamEdiyorMu = true

print(ogrenciAdi)
print(ogrenciYas)
print(ogrenciBoy)
print(ogrenciBharf)

var urun_id:Int = 3416
var urun_adi:String = "Macbook Pro"
var urun_adet:Int = 100
var urun_fiyat:Int = 34999
var urun_tedarikci:String = "Apple"

print("Ürün ID       : \(urun_id)")
print("Ürün Adı      : \(urun_adi)")
print("Ürün Adet     : \(urun_adet)")
print("Ürün Fiyat    : \(urun_fiyat) ")
print("Ürün Tedarikçi: \(urun_tedarikci)")
